﻿// Core constants exports
