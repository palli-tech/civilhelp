class Labour {
  final String? id;
  final String name;
  final String phone;
  final String? email;
  final String? address;
  final String? skill;
  final double? hourlyRate;
  final bool isActive;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  Labour({
    this.id,
    required this.name,
    required this.phone,
    this.email,
    this.address,
    this.skill,
    this.hourlyRate,
    this.isActive = true,
    this.createdAt,
    this.updatedAt,
  });

  Labour copyWith({
    String? id,
    String? name,
    String? phone,
    String? email,
    String? address,
    String? skill,
    double? hourlyRate,
    bool? isActive,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return Labour(
      id: id ?? this.id,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      email: email ?? this.email,
      address: address ?? this.address,
      skill: skill ?? this.skill,
      hourlyRate: hourlyRate ?? this.hourlyRate,
      isActive: isActive ?? this.isActive,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  @override
  String toString() {
    return 'Labour{id: $id, name: $name, phone: $phone, email: $email, address: $address, skill: $skill, hourlyRate: $hourlyRate, isActive: $isActive, createdAt: $createdAt, updatedAt: $updatedAt}';
  }
}