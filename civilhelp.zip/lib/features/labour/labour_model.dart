import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:civilhelp/core/enums/labour_status.dart';

class LabourModel {
  final String id;
  final String fullName;
  final String phoneNumber;
  final String aadhaarNumber;
  final double dailyWage;
  final String assignedSiteId;
  final String assignedSiteName;
  final LabourStatus status;
  final DateTime joinedDate;
  final String companyId;
  final DateTime createdAt;
  final String createdBy;

  const LabourModel({
    required this.id,
    required this.fullName,
    required this.phoneNumber,
    required this.aadhaarNumber,
    required this.dailyWage,
    required this.assignedSiteId,
    required this.assignedSiteName,
    required this.status,
    required this.joinedDate,
    required this.companyId,
    required this.createdAt,
    required this.createdBy,
  });

  factory LabourModel.fromMap(Map<String, dynamic> map, String documentId) {
    return LabourModel(
      id: documentId,
      fullName: map['fullName'] ?? '',
      phoneNumber: map['phoneNumber'] ?? '',
      aadhaarNumber: map['aadhaarNumber'] ?? '',
      dailyWage: (map['dailyWage'] as num?)?.toDouble() ?? 0.0,
      assignedSiteId: map['assignedSiteId'] ?? '',
      assignedSiteName: map['assignedSiteName'] ?? '',
      status: LabourStatus.values.firstWhere(
        (e) => e.name == map['status'],
        orElse: () => LabourStatus.active,
      ),
      joinedDate: (map['joinedDate'] as Timestamp).toDate(),
      companyId: map['companyId'] ?? '',
      createdAt: (map['createdAt'] as Timestamp).toDate(),
      createdBy: map['createdBy'] ?? '',
    );
  }

  factory LabourModel.fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data();

    if (data == null) {
      throw Exception('Labour document does not exist');
    }

    return LabourModel.fromMap(data, doc.id);
  }

  Map<String, dynamic> toMap() {
    return {
      'fullName': fullName,
      'phoneNumber': phoneNumber,
      'aadhaarNumber': aadhaarNumber,
      'dailyWage': dailyWage,
      'assignedSiteId': assignedSiteId,
      'assignedSiteName': assignedSiteName,
      'status': status.name,
      'joinedDate': Timestamp.fromDate(joinedDate),
      'companyId': companyId,
      'createdAt': Timestamp.fromDate(createdAt),
      'createdBy': createdBy,
    };
  }

  LabourModel copyWith({
    String? id,
    String? fullName,
    String? phoneNumber,
    String? aadhaarNumber,
    double? dailyWage,
    String? assignedSiteId,
    String? assignedSiteName,
    LabourStatus? status,
    DateTime? joinedDate,
    String? companyId,
    DateTime? createdAt,
    String? createdBy,
  }) {
    return LabourModel(
      id: id ?? this.id,
      fullName: fullName ?? this.fullName,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      aadhaarNumber: aadhaarNumber ?? this.aadhaarNumber,
      dailyWage: dailyWage ?? this.dailyWage,
      assignedSiteId: assignedSiteId ?? this.assignedSiteId,
      assignedSiteName: assignedSiteName ?? this.assignedSiteName,
      status: status ?? this.status,
      joinedDate: joinedDate ?? this.joinedDate,
      companyId: companyId ?? this.companyId,
      createdAt: createdAt ?? this.createdAt,
      createdBy: createdBy ?? this.createdBy,
    );
  }
}
