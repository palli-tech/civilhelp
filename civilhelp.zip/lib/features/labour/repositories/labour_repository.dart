import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/labour_model.dart';

class LabourRepository {
  final FirebaseFirestore _firestore;

  LabourRepository({FirebaseFirestore? firestore})
      : _firestore = firestore ?? FirebaseFirestore.instance;

  Future<void> create(Labour labour) async {
    final docRef = _firestore.collection('labour').doc();
    await docRef.set({
      'name': labour.name,
      'phone': labour.phone,
      'email': labour.email,
      'address': labour.address,
      'skill': labour.skill,
      'hourlyRate': labour.hourlyRate,
      'isActive': labour.isActive,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<List<Labour>> readAll() async {
    final snapshot = await _firestore.collection('labour').get();
    return snapshot.docs.map((doc) {
      final data = doc.data();
      return Labour(
        id: doc.id,
        name: data['name'] ?? '',
        phone: data['phone'] ?? '',
        email: data['email'],
        address: data['address'],
        skill: data['skill'],
        hourlyRate: (data['hourlyRate'] as num?)?.toDouble(),
        isActive: data['isActive'] ?? true,
        createdAt: (data['createdAt'] as Timestamp?)?.toDate(),
        updatedAt: (data['updatedAt'] as Timestamp?)?.toDate(),
      );
    }).toList();
  }

  Future<Labour?> readById(String id) async {
    final docSnapshot = await _firestore.collection('labour').doc(id).get();
    if (!docSnapshot.exists) return null;
    final data = docSnapshot.data();
    return Labour(
      id: docSnapshot.id,
      name: data['name'] ?? '',
      phone: data['phone'] ?? '',
      email: data['email'],
      address: data['address'],
      skill: data['skill'],
      hourlyRate: (data['hourlyRate'] as num?)?.toDouble(),
      isActive: data['isActive'] ?? true,
      createdAt: (data['createdAt'] as Timestamp?)?.toDate(),
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate(),
    );
  }

  Future<void> update(Labour labour) async {
    final docRef = _firestore.collection('labour').doc(labour.id);
    await docRef.update({
      'name': labour.name,
      'phone': labour.phone,
      'email': labour.email,
      'address': labour.address,
      'skill': labour.skill,
      'hourlyRate': labour.hourlyRate,
      'isActive': labour.isActive,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> delete(String id) async {
    await _firestore.collection('labour').doc(id).delete();
  }

  Future<List<Labour>> searchByName(String query) async {
    final snapshot = await _firestore
        .collection('labour')
        .where('name', isGreaterThanOrEqualTo: query)
        .where('name', isLessThanOrEqualTo: query + '')
        .get();
    return snapshot.docs.map((doc) {
      final data = doc.data();
      return Labour(
        id: doc.id,
        name: data['name'] ?? '',
        phone: data['phone'] ?? '',
        email: data['email'],
        address: data['address'],
        skill: data['skill'],
        hourlyRate: (data['hourlyRate'] as num?)?.toDouble(),
        isActive: data['isActive'] ?? true,
        createdAt: (data['createdAt'] as Timestamp?)?.toDate(),
        updatedAt: (data['updatedAt'] as Timestamp?)?.toDate(),
      );
    }).toList();
  }

  Future<List<Labour>> getActive() async {
    final snapshot = await _firestore.collection('labour').where('isActive', isEqualTo: true).get();
    return snapshot.docs.map((doc) {
      final data = doc.data();
      return Labour(
        id: doc.id,
        name: data['name'] ?? '',
        phone: data['phone'] ?? '',
        email: data['email'],
        address: data['address'],
        skill: data['skill'],
        hourlyRate: (data['hourlyRate'] as num?)?.toDouble(),
        isActive: data['isActive'] ?? true,
        createdAt: (data['createdAt'] as Timestamp?)?.toDate(),
        updatedAt: (data['updatedAt'] as Timestamp?)?.toDate(),
      );
    }).toList();
  }
}